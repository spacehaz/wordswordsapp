const express = require('express');
const app = express();
const port = 3000;
const path = require('path')
const bodyParser = require('body-parser')
const { createCanvas } = require('canvas')

app.use(bodyParser.json())
app.use(bodyParser.urlencoded({ extended: true }))

app.use(express.static('public'));

app.post('/generate-image', (req, res, next) => {
	const WIDTH = 1080;
	const HEIGHT = 1080;
	const { hex = "#222222" , word = '' } = req.body
	const canvas = createCanvas(WIDTH, HEIGHT);
	const ctx = canvas.getContext("2d");
	ctx.fillStyle = `${hex}`;
	ctx.fillRect(0, 0, WIDTH, HEIGHT);
	ctx.fillStyle = "#FEFEFE";
	ctx.font = "108px Arial";
	ctx.textAlign = 'center';
	ctx.textBaseline = 'middle';
	ctx.fillText(word.toUpperCase(), 1080/2, 1080/2);
	const buffer = canvas.toBuffer("image/png")
	res.status(200).send(buffer)
})

app.get('*', (req, res, next) => {
	res.status(404).send('Sorry, page not found')
	next()
})

app.listen(port, () => {
	console.log(`Server started at port ${port}`)
})